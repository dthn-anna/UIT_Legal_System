-- 1. Kích hoạt extension hỗ trợ vector (pgvector)
create extension if not exists vector;

-- 2. Tạo bảng lưu quy chế học đường
create table if not exists school_regulations (
  id bigserial primary key,
  content text not null,          -- Nội dung đoạn quy định/điều khoản
  metadata jsonb,                 -- metadata lưu: doc_name, article_num, original_qa_list, v.v.
  embedding vector(768)          -- Vector 768 chiều cho Gemini text-embedding-004
);

-- 3. Tạo HNSW index để tăng tốc tìm kiếm tương đồng vector
create index if not exists school_regulations_embedding_idx 
on school_regulations 
using hnsw (embedding vector_cosine_ops);

-- 4. Tạo hàm tìm kiếm tương đồng Cosine
create or replace function match_regulations (
  query_embedding vector(768),
  match_threshold float,
  match_count int
)
returns table (
  id bigint,
  content text,
  metadata jsonb,
  similarity float
)
language sql stable
as $$
  select
    id,
    content,
    metadata,
    1 - (school_regulations.embedding <=> query_embedding) as similarity
  from school_regulations
  where 1 - (school_regulations.embedding <=> query_embedding) > match_threshold
  order by school_regulations.embedding <=> query_embedding
  limit match_count;
$$;
