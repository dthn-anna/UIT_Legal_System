"""
Xây dựng máy chủ API FastAPI.
Cung cấp endpoint chính /chat nhận câu hỏi của sinh viên, gọi retriever.py để tìm các điều luật liên quan nhất, dựng prompt RAG nghiêm ngặt và gửi yêu cầu tới mô hình ngôn ngữ Gemini 2.0 Flash (thông qua OpenRouter) để sinh câu trả lời tự nhiên.
Cung cấp các endpoint phụ /settings để điều chỉnh động giá trị α từ giao diện người dùng và /refresh-index để nạp lại dữ liệu BM25 khi tri thức thay đổi.
"""

import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from dotenv import load_dotenv
import requests


# Import bộ truy xuất Hybrid
from retriever import HybridRetriever

# Load env variables
load_dotenv()

# --- Cấu hình Ollama (Generator local) ---
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL    = os.getenv("OLLAMA_MODEL", "qwen3:8b")

app = FastAPI(
    title="UIT Legal System Chatbot API",
    description= (
        "FastAPI Backend sử dụng Hybrid Search "
        "(vietnamese-bi-encoder + BM25) và Qwen3-8B (Ollama local)"
    ),
    version="2.0.0"
)

# Cấu hình CORS để cho phép kết nối từ Frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Trong thực tế, giới hạn tên miền web chính thức của trường
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Khởi tạo module tìm kiếm Hybrid (mặc định alpha = 0.5)
# Alpha có thể điều chỉnh để ưu tiên tìm kiếm theo ngữ nghĩa (Dense) hay từ khóa (Sparse/BM25)
ALPHA_WEIGHT = float(os.getenv("HYBRID_ALPHA", 0.5))
retriever = HybridRetriever(alpha=ALPHA_WEIGHT)

class ChatRequest(BaseModel):
    message: str

class SettingsRequest(BaseModel):
    alpha: float

class SourceItem(BaseModel):
    id: int
    content: str
    document: str
    article: str
    hybrid_score: float

class ChatResponse(BaseModel):
    answer: str
    sources: List[SourceItem]

# --- Helper: gọi Ollama ---
def call_ollama(prompt: str) -> str:
    """
    Gọi Ollama API (OpenAI-compatible endpoint) với model Qwen3:8B.
    Ollama expose endpoint /v1/chat/completions tương thích OpenAI.
    """
    url = f"{OLLAMA_BASE_URL}/v1/chat/completions"
    payload = {
        "model": OLLAMA_MODEL,
        "messages": [
            {
                "role": "system",
                "content": (
                    "Bạn là trợ lý ảo hỗ trợ giải đáp thắc mắc về quy định, "
                    "quy chế đào tạo và quy chế học tập tại trường đại học. "
                    "Chỉ trả lời dựa trên tài liệu được cung cấp. "
                    "Trả lời bằng tiếng Việt, lịch sự và chính xác."
                )
            },
            {"role": "user", "content": prompt}
        ],
        "stream": False,
        "options": {
            "temperature": 0.1,   # Thấp để câu trả lời sát tài liệu, ít sáng tạo
            "num_predict": 1024,
        }
    }
    response = requests.post(url, json=payload, timeout=120)
    if response.status_code != 200:
        raise RuntimeError(
            f"Ollama API lỗi {response.status_code}: {response.text[:300]}"
        )
    return response.json()["choices"][0]["message"]["content"]


@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    query_text = request.message.strip()
    if not query_text:
        raise HTTPException(status_code=400, detail="Câu hỏi không được để trống.")
        
    try:
        # 1. Truy xuất các tài liệu/điều luật liên quan bằng bộ truy xuất Hybrid
        matched_docs = retriever.retrieve(query=query_text, top_k=3)
        
        # 2. Xây dựng văn cảnh (Context) và danh sách nguồn tham khảo
        context_parts = []
        sources = []
        
        for idx, doc in enumerate(matched_docs):
            doc_title = f"{doc['metadata'].get('document', '')} - {doc['metadata'].get('article', '')}"
            sources.append(SourceItem(
                id=doc['id'],
                content=doc['content'],
                document=doc['metadata'].get('document', ''),
                article=doc['metadata'].get('article', ''),
                hybrid_score=doc['hybrid_score']
            ))
            context_parts.append(f"[Tài liệu {idx+1}] Tiêu đề: {doc_title}\nNội dung: {doc['content']}")
            
        context_text = "\n\n".join(context_parts) if context_parts else "Không tìm thấy điều luật phù hợp."
        
        # 3. Tạo Prompt hướng dẫn RAG nghiêm ngặt cho LLM
        prompt = f"""Sử dụng các quy định được cung cấp dưới đây để trả lời câu hỏi của sinh viên.

YÊU CẦU NGHIÊM NGẶT:
1. Chỉ dựa vào các tài liệu được cung cấp trong phần "TÀI LIỆU THAM KHẢO".
2. Nếu tài liệu không đủ thông tin, trả lời: "Tôi không tìm thấy thông tin này trong quy định hiện hành của trường. Vui lòng liên hệ phòng Đào tạo để được hỗ trợ chi tiết."
3. Không tự tiện thêm thông tin, số liệu, mốc thời gian ngoài tài liệu.
4. Nếu trích dẫn Điều/Khoản, phải nêu rõ tên Điều/Khoản đó.


TÀI LIỆU THAM KHẢO:
{context_text}

CÂU HỎI CỦA SINH VIÊN:
{query_text}

TRẢ LỜI:"""

        # 4. Gọi Qwen3:8B qua Ollama
        answer = call_ollama(prompt)

        return ChatResponse(answer=answer, sources=sources)


    except Exception as e:
        print(f"Lỗi xử lý Chat API: {e}")
        raise HTTPException(status_code=500, detail=f"Lỗi hệ thống: {str(e)}")


@app.get("/settings")
async def get_settings():
    """Lấy cấu hình hiện tại."""
    return {
        "alpha": retriever.alpha,
        "ollama_model": OLLAMA_MODEL,
        "ollama_url": OLLAMA_BASE_URL,
        "alpha_description": "alpha=1.0 là thuần Dense Search, alpha=0.0 là thuần BM25."
    }


@app.post("/settings")
async def update_settings(settings: SettingsRequest):
    """Cập nhật động trọng số alpha mà không cần restart server."""
    if not (0.0 <= settings.alpha <= 1.0):
        raise HTTPException(
            status_code=400,
            detail="Trọng số alpha phải trong khoảng [0.0, 1.0]."
        )
    retriever.alpha = settings.alpha
    return {"status": "success", "new_alpha": retriever.alpha}


@app.post("/refresh-index")
async def refresh_index():
    """Reload BM25 index và corpus embeddings khi có quy chế mới."""
    retriever.refresh_bm25_index()
    return {"status": "success", "total_documents": len(retriever.documents)}


@app.get("/health")
async def health_check():
    """Kiểm tra trạng thái server và kết nối Ollama."""
    try:
        resp = requests.get(f"{OLLAMA_BASE_URL}/api/tags", timeout=5)
        ollama_ok = resp.status_code == 200
        models = [m["name"] for m in resp.json().get("models", [])] if ollama_ok else []
    except Exception:
        ollama_ok = False
        models = []

    return {
        "status": "ok",
        "ollama_connected": ollama_ok,
        "ollama_model": OLLAMA_MODEL,
        "available_models": models,
        "total_documents": len(retriever.documents),
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
