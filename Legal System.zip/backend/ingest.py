"""
- Script nạp dữ liệu tri thức RAG từ Excel vào Supabase.
- Đọc song song 3 tệp dữ liệu (train.xlsx, val.xlsx, test.xlsx), tiến hành loại bỏ hoàn toàn trùng lặp văn cảnh (context) để tránh lãng phí chi phí lưu trữ vector.
- Sử dụng mô hình vietnamese-bi-encoder từ Hugging Face để sinh vector 768 chiều cho từng văn cảnh và đẩy dữ liệu (gồm nội dung, metadata tiêu đề điều luật, danh sách QA thô gốc) lên bảng school_regulations.
"""

import os 
import pandas as pd
from supabase import create_client, Client
from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_SERVICE_ROLE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "bkai-foundation-models/vietnamese-bi-encode")

if not SUPABASE_URL or not SUPABASE_SERVICE_ROLE_KEY or not EMBEDDING_MODEL:
    print("Vui lòng bổ sung thông tin các API key.")
    exit(1)


supabase: Client = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

print("Loading embedding model.")
model = SentenceTransformer(EMBEDDING_MODEL)
print("Loading embedding model completely.")

def get_embedding(text: str):
    return model.encode(text, normalize_embeddings= True).tolist()

def run_ingestion():
    excel_file = [
        r'../ViRHE4QA/raw_excel/train.xlsx',
        r'../ViRHE4QA/raw_excel/dev.xlsx',
        r'../ViRHE4QA/raw_excel/test.xlsx'
    ]

    existing_files = [f for f in excel_file if os.path.exists(f)]
    if not existing_files:
        print("Can't find any data file in path.")
        return
    
    print(f"Start reading {len(existing_files)} file in dataset.")

    unique_contexts = {}
    total_raw_rows = 0 

    for file_path in existing_files:
        file_name = os.path.basename(file_path)
        print(f"Reading {file_name}")
        df = pd.read_excel(file_path)
        total_raw_rows += len(df)


        for idx, row in df.iterrows():
            context = str(row['context']).strip()
            document = str(row['document']).strip()
            article = str(row['article']).strip()
            question = str(row['question']).strip()
            answer = str(row['abstractive answer']).strip()

            if context not in unique_contexts:
                unique_contexts[context] = {
                    "document": document,
                    "article": article,
                    "qa_pairs": []
                }

            qa_pair = {"question": question,
                       "answer": answer,
                       }
            if qa_pair not in unique_contexts[context]["qa_pairs"]:
                unique_contexts[context]["qa_pairs"].append(qa_pair)

    print(f"The total of raw samples is: {total_raw_rows}")
    print(f"Actual number of unique regulatory article: {len(unique_contexts)} ")

    # Xỏa bảng cũ trước khi nạp - Làm sạch dữ liệu cũ: 
    # supabase.table("school_regulations").delete().neq("id", 0).execute()

    context_list = list(unique_contexts.items())
    
    text_to_embed = [
        f"Văn bản: {info['document']} - {info['article']}\nNội dung: {context}"
        for info, context in context_list 
    ]

    print("Generating embedded vector for all of corpus.")
    all_vectors = model.encode(
        text_to_embed,
        batch_size= 32,
        show_progress_bar= True, 
        normalize_embeddings= True
    )
    print("Generated embedded vector completely. Starting upload into supabase.")

    for count, ((context, info), vector) in enumerate(zip(context_list, all_vectors)):
        doc_title = f"{info['document']} - {info['article']}"
        print(f"[{count/len(context_list)}] - {doc_title}")
        try:
            supabase.table("school_regulations").insert({
                "context": context,
                "metadata": {
                    "document": info['document'],
                    "article" : info['article'],
                    "qa_pairs": info['qa_pairs']
                },
                "embedding": vector.tolist()
            }).execute()
        except Exception as e:
            print(f"Error in line {count}: {e}")
    
    print("\nUpdated data completely.")


if __name__ == "__main__":
    run_ingestion()



            