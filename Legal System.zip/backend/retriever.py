import os
import numpy as np
from typing import List, Dict, Any
from rank_bm25 import BM25Okapi
from underthesea import word_tokenize
from supabase import create_client, Client
from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv

# Load env variables
load_dotenv()

class HybridRetriever:
    def __init__(self, alpha: float = 0.5):
        """
        Khởi tạo Hybrid Retriever kết hợp Bi-Encoder (Dense) và BM25 (Sparse).
        :param alpha: Trọng số kết hợp. 
                      Score = alpha * Score_Dense_Norm + (1 - alpha) * Score_Sparse_Norm
                      alpha = 1.0: Chỉ dùng Bi-Encoder (Dense)
                      alpha = 0.0: Chỉ dùng BM25 (Sparse)
        """
        self.alpha = alpha
        
        # Khởi tạo Supabase client
        supabase_url = os.getenv("SUPABASE_URL")
        supabase_anon_key = os.getenv("SUPABASE_ANON_KEY")
        self.supabase: Client = create_client(supabase_url, supabase_anon_key)
        
        # Load model embedding 
        embedding_model_name = os.getenv(
            "EMBEDDING_MODEL",
            "bkai-foundation-models/vietnamese-bi-encoder"
        )
        print(f"Đang load embedding model: {embedding_model_name} ...")
        self.embedding_model = SentenceTransformer(embedding_model_name)
        print("Load embedding model thành công.")
        

        # Cache vector corpus để không tính lại mỗi lần query
        self.documents: List[Dict[str, Any]] = []
        self.bm25_index: BM25Okapi = None
        self.corpus_embeddings: np.ndarray = None  # shape: (N, dim)
        
        # Tải dữ liệu từ Supabase và build index
        self.refresh_bm25_index()

    def refresh_bm25_index(self):
        """Tải toàn bộ văn bản từ Supabase, build chỉ mục BM25 và tính
        sẵn vector embedding cho toàn bộ corpus (cache vào RAM)"""

        try:
            print("Đang tải dữ liệu từ database...")
            response = self.supabase.table("school_regulations").select("id, content, metadata").execute()
            self.documents = response.data
            
            if not self.documents:
                print("Database rỗng hoặc chưa nạp dữ liệu. Vui lòng chạy ingest.py trước.")
                return

            # Build BM25 index
            tokenized_corpus = []
            corpus_texts = []

            for doc in self.documents:
                text = (
                    f"{doc['metadata'].get('document', '')}" 
                    f"{doc['metadata'].get('article', '')}" 
                    f"{doc['content']}"
                )
                # Chuyển thành chữ thường và tokenize
                tokens = word_tokenize(text.lower(), format="text").split()
                tokenized_corpus.append(tokens)
                corpus_texts.append(text)
                
            self.bm25_index = BM25Okapi(tokenized_corpus)
            print(f"Đã tạo chỉ mục BM25 cho {len(self.documents)} văn bản quy chế.")

            # Tính embeding
            self.corpus_embeddings = self.embedding_model.encode(
                corpus_texts,
                batch_size= 32,
                show_progress_bar= True,
                normalize_embeddings= True
                )
            
            print(f"Đã tính xong embedding corpus: shape {self.corpus_embeddings.shape}")

        except Exception as e:
            print(f"Lỗi khởi tạo chỉ mục BM25: {e}")

    def _get_query_embedding(self, query: str) -> np.ndarray:
        """Tạo vector embedding cho câu hỏi."""
        return self.embedding_model.encode(
            query,
            normalize_embeddings=True
        )

    def _normalize_scores(self, scores: np.ndarray) -> np.ndarray:
        """Chuẩn hóa điểm số về khoảng [0, 1] sử dụng Min-Max Scaling."""
        min_val = np.min(scores)
        max_val = np.max(scores)
        if max_val - min_val == 0:
            return np.zeros_like(scores)
        return (scores - min_val) / (max_val - min_val)

    def retrieve(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        """
        Thực hiện truy xuất văn bản kết hợp Hybrid Search (Dense + Sparse).
        """
        if not self.documents or self.bm25_index is None:
            # Fallback nếu BM25 chưa khởi tạo
            self.refresh_bm25_index()
            if not self.documents:
                return []

        # TRUY XUẤT SPARSE (BM25)
        # Tokenize câu truy vấn
        query_tokens = word_tokenize(query.lower(), format="text").split()
        bm25_scores = np.array(self.bm25_index.get_scores(query_tokens))
        
        # TRUY XUẤT DENSE (Bi-Encoder qua Supabase Vector)
        query_vector = self._get_query_embedding(query)
        # corpus_embeddings đã normalize → dot product = cosine similarity
        dense_scores = self.corpus_embeddings @ query_vector  # shape: (N,)

        # Hybrid scoring 
        norm_dense = self._normalize_scores(dense_scores)
        norm_sparse = self._normalize_scores(bm25_scores)
        hybrid_scores = self.alpha * norm_dense + (1 - self.alpha) * norm_sparse

        # Lấy top-k
        top_indices = np.argsort(hybrid_scores)[::-1][:top_k]
        
        results = []
        for idx in top_indices:
            doc = self.documents[idx]
            results.append({
                "id": doc["id"],
                "content": doc["content"],
                "metadata": doc["metadata"],
                "dense_score": float(dense_scores[idx]),
                "sparse_score": float(bm25_scores[idx]),
                "hybrid_score": float(hybrid_scores[idx])
            })
            
        return results
