const API_BASE = 'http://localhost:8000';

// Đọc giá trị alpha hiện tại từ server khi load trang
document.addEventListener('DOMContentLoaded', async () => {
  try {
    const response = await fetch(`${API_BASE}/settings`);
    if (response.ok) {
      const data = await response.json();
      document.getElementById('alpha-slider').value = data.alpha;
      document.getElementById('alpha-val').innerText = data.alpha;
    }
  } catch (err) {
    console.error('Không kết nối được tới Backend FastAPI:', err);
  }
});

// Hàm cập nhật trọng số alpha lên server khi trượt thanh điều chỉnh
async function updateAlpha(val) {
  document.getElementById('alpha-val').innerText = val;
  try {
    await fetch(`${API_BASE}/settings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ alpha: parseFloat(val) })
    });
  } catch (err) {
    console.error('Lỗi cập nhật trọng số alpha:', err);
  }
}

// Reset hội thoại về ban đầu
function resetChat() {
  const container = document.getElementById('messages-container');
  container.innerHTML = `
    <div class="message system-message">
      <div class="avatar">AI</div>
      <div class="message-body">
        <p>Xin chào! Tôi là trợ lý ảo hỗ trợ tra cứu quy định học vụ của trường dựa trên tập dữ liệu nghiên cứu <strong>ViRHE4QA</strong>.</p>
        <p>Hãy hỏi tôi bất kỳ thắc mắc nào về học chế tín chỉ, đăng ký môn học, cảnh cáo học vụ hay tiêu chuẩn xếp loại tốt nghiệp.</p>
        
        <div class="quick-queries">
          <button onclick="sendQuickQuery('Sinh viên bị cảnh cáo học tập được đăng ký tối thiểu bao nhiêu tín chỉ?')">Sinh viên cảnh cáo học tập đăng ký tối thiểu bao nhiêu tín chỉ?</button>
          <button onclick="sendQuickQuery('GPA bao nhiêu thì được xếp loại học lực khá?')">GPA bao nhiêu thì được xếp loại học lực khá?</button>
          <button onclick="sendQuickQuery('Học viên bị buộc thôi học trong trường hợp nào?')">Khi nào sinh viên bị buộc thôi học?</button>
        </div>
      </div>
    </div>
  `;
}

// Gửi câu hỏi nhanh
function sendQuickQuery(text) {
  document.getElementById('user-input').value = text;
  sendMessage();
}

// Gửi tin nhắn chính
async function sendMessage() {
  const inputEl = document.getElementById('user-input');
  const queryText = inputEl.value.trim();
  if (!queryText) return;

  // Xóa nội dung input
  inputEl.value = '';

  const container = document.getElementById('messages-container');

  // 1. Thêm tin nhắn của User vào giao diện
  const userMsgDiv = document.createElement('div');
  userMsgDiv.className = 'message user-message';
  userMsgDiv.innerHTML = `
    <div class="avatar">U</div>
    <div class="message-body">
      <p>${queryText}</p>
    </div>
  `;
  container.appendChild(userMsgDiv);
  container.scrollTop = container.scrollHeight;

  // 2. Thêm hiệu ứng Loading đang trả lời
  const loadingDiv = document.createElement('div');
  loadingDiv.className = 'message system-message';
  loadingDiv.id = 'chat-loading-indicator';
  loadingDiv.innerHTML = `
    <div class="avatar">AI</div>
    <div class="message-body">
      <div class="loader-dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  `;
  container.appendChild(loadingDiv);
  container.scrollTop = container.scrollHeight;

  try {
    // 3. Gửi request tới FastAPI Backend
    const response = await fetch(`${API_BASE}/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message: queryText })
    });

    const data = await response.json();

    // Xóa loading indicator
    document.getElementById('chat-loading-indicator').remove();

    if (!response.ok) {
      throw new Error(data.detail || 'Lỗi xử lý câu trả lời.');
    }

    // 4. Hiển thị câu trả lời và nguồn trích dẫn
    const botMsgDiv = document.createElement('div');
    botMsgDiv.className = 'message system-message';
    
    // Lắp ghép giao diện trích nguồn
    let sourcesHtml = '';
    if (data.sources && data.sources.length > 0) {
      sourcesHtml = `
        <div class="sources-box">
          <div class="sources-header">Văn bản pháp lý đối chiếu (Hybrid Match):</div>
          <div class="sources-list">
            ${data.sources.map(src => `
              <span class="source-item" title="Nội dung điều luật: ${src.content.substring(0, 100)}...\nĐiểm lai (Hybrid Score): ${src.hybrid_score.toFixed(3)}">
                📖 ${src.document} - ${src.article} (Hybrid Score: ${src.hybrid_score.toFixed(2)})
              </span>
            `).join('')}
          </div>
        </div>
      `;
    }

    botMsgDiv.innerHTML = `
      <div class="avatar">AI</div>
      <div class="message-body">
        <p style="white-space: pre-line;">${data.answer}</p>
        ${sourcesHtml}
      </div>
    `;
    container.appendChild(botMsgDiv);
    container.scrollTop = container.scrollHeight;

  } catch (err) {
    console.error(err);
    document.getElementById('chat-loading-indicator')?.remove();
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'message system-message';
    errorDiv.innerHTML = `
      <div class="avatar">⚠️</div>
      <div class="message-body">
        <p style="color: #ef4444;">Lỗi: Không kết nối được đến máy chủ FastAPI (${API_BASE}). Vui lòng đảm bảo backend đang chạy (python main.py).</p>
      </div>
    `;
    container.appendChild(errorDiv);
    container.scrollTop = container.scrollHeight;
  }
}
